<?php

return function(Exception $error) {
    return [
        'status' => false,
        'message' => $error->getMessage()
    ];
};

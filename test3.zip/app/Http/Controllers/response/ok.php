<?php

return function($data) {
    return [
        'status' => true,
        'message' => $data
    ];
};

<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

return function(Request $request, $rules) {
  $validator = Validator::make($request->all(), $rules);
  if ($validator->fails()) {
    $errors = $validator->errors()->messages();
    throw new Exception(
      implode(
        "; ", 
        array_map(function($curr_key) use($errors) {
          $curr_value = $errors[$curr_key];
          $arraystring = implode(", ", $curr_value);
          return "$curr_key: $arraystring";
        }, array_keys($errors))
      )
    );
  }
};
